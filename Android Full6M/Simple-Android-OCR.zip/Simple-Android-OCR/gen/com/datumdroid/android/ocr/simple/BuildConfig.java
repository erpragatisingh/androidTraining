/** Automatically generated file. DO NOT MODIFY */
package com.datumdroid.android.ocr.simple;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}